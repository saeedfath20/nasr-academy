/* Appearance, isolated printing and manager-only SMS center. */
window.NasrFeatures = function (A) {
  'use strict';
  const {root,S,C,h,num,date,dateInput,today,field,select,check,button,link,sectionHead,empty,pager,api,toast,modal,closeModal,formData,render,reportTable,reportSummary,reportMetadata,comprehensiveClassReport,teacherPayReport,studentGradesReport,englishName,fullName,isManager,academicReports,financialReports} = A;
  const pref=()=>S.boot.settings.preferences;
  const reportNames=()=>Object.fromEntries([...academicReports,...financialReports,['class_roster','فهرست داخل کلاس']]);
  const labelMap={font_size:'اندازهٔ متن اصلی',small_font_size:'اندازهٔ متن راهنما',heading_size:'اندازهٔ عنوان‌ها',menu_font_size:'اندازهٔ منو',table_font_size:'اندازهٔ متن جدول',line_height:'فاصلهٔ خط‌ها',color_primary:'رنگ اصلی و دکمه‌ها',color_sidebar:'رنگ پس‌زمینهٔ منو',color_background:'رنگ زمینهٔ صفحه',color_text:'رنگ متن',color_accent:'رنگ تأکید',color_border:'رنگ خطوط'};
  const colors=['color_primary','color_sidebar','color_background','color_text','color_accent','color_border'];
  function preferences(){
    const p=pref(),catalog=S.boot.settings.print_catalog || {};
    return `<div class="nasr-settings-group"><h3>فونت و ظاهر</h3><div class="nasr-form-grid">${select('خانوادهٔ فونت','pref_font_family',p.font_family,[['NasrFont','فونت فارسی نصر'],['Tahoma','Tahoma'],['Arial','Arial']])}${select('وزن متن','pref_font_weight',p.font_weight,[['400','معمولی'],['500','متوسط'],['700','ضخیم']])}${['font_size','small_font_size','heading_size','menu_font_size','table_font_size','line_height'].map(k=>field(labelMap[k],'pref_'+k,p[k],{mode:'decimal',dir:'ltr',help:k==='line_height'?'بین ۱٫۲ و ۲٫۵':'بر حسب پیکسل'})).join('')}${select('فاصلهٔ ردیف‌ها','pref_density',p.density,[['normal','معمولی'],['compact','فشرده']])}${colors.map(k=>field(labelMap[k],'pref_'+k,p[k],{type:'color'})).join('')}</div></div>
    <div class="nasr-settings-group"><h3>چاپ و PDF</h3><div class="nasr-form-grid">${select('اندازهٔ کاغذ','pref_print_paper',p.print_paper,[['A4','A4'],['A5','A5'],['Letter','Letter']])}${select('جهت صفحه','pref_print_orientation',p.print_orientation,[['landscape','افقی'],['portrait','عمودی']])}${field('حاشیهٔ کاغذ (میلی‌متر)','pref_print_margin',p.print_margin,{mode:'numeric',dir:'ltr'})}${field('اندازهٔ فونت چاپ (پیکسل)','pref_print_font_size',p.print_font_size,{mode:'numeric',dir:'ltr'})}${field('فاصلهٔ داخل سلول (پیکسل)','pref_print_padding',p.print_padding,{mode:'numeric',dir:'ltr'})}${[['print_academy','نام آموزشگاه'],['print_context','مشخصات شعبه، ترم و کلاس'],['print_date','تاریخ تهیهٔ گزارش'],['print_summary','جمع‌ها و خلاصهٔ گزارش'],['print_notes','توضیحات گزارش و کلاس'],['print_zebra','زمینهٔ یک‌درمیان ردیف‌ها']].map(([k,label])=>check(label,'pref_'+k,p[k])).join('')}${field('متن دلخواه پایین گزارش','pref_print_footer',p.print_footer,{wide:true,maxlength:300,help:'خالی بگذارید تا پاورقی چاپ نشود.'})}</div>
    <div class="nasr-print-catalog">${Object.entries(catalog).map(([type,columns])=>`<details><summary>${h(reportNames()[type] || type)}</summary><div class="nasr-check-grid">${Object.entries(columns).map(([key,label])=>`<label class="nasr-check"><input type="checkbox" data-print-type="${h(type)}" value="${h(key)}" ${(p.print_columns[type] || Object.keys(columns)).includes(key)?'checked':''}>${h(label)}</label>`).join('')}</div></details>`).join('')}</div></div>`;
  }
  function readPreferences(form){
    const p={},data=formData(form);for(const key of Object.keys(pref()))if(key!=='print_columns' && Object.hasOwn(data,'pref_'+key))p[key]=data['pref_'+key];
    p.print_columns={};form.querySelectorAll('[data-print-type]').forEach(el=>{const k=el.dataset.printType;p.print_columns[k] ||= [];if(el.checked)p.print_columns[k].push(el.value);});
    return p;
  }
  function applyAppearance(){
    const p=pref();if(!p)return;
    const vars={navy:p.color_sidebar,blue:p.color_primary,green:p.color_accent,ink:p.color_text,line:p.color_border,'nasr-bg':p.color_background,'nasr-font-scale':p.font_size/16,'nasr-small':p.small_font_size+'px','nasr-heading':p.heading_size+'px','nasr-menu':p.menu_font_size+'px','nasr-table':p.table_font_size+'px'};
    Object.entries(vars).forEach(([k,v])=>root.style.setProperty('--'+k,v));Object.assign(root.style,{fontFamily:p.font_family+',Tahoma,Arial,sans-serif',fontSize:p.font_size+'px',fontWeight:p.font_weight,lineHeight:p.line_height});root.dataset.density=p.density;
    if(document.body.classList.contains('nasr-portal'))document.body.style.setProperty('background',p.color_background,'important');
    const nav=root.querySelector('.nasr-sidebar nav');if(nav){nav.setAttribute('tabindex','0');nav.setAttribute('data-lenis-prevent','');nav.setAttribute('data-scroll-lock-scrollable','');}
  }
  root.addEventListener('wheel',e=>{
    if(e.ctrlKey || e.target.closest('select,option'))return;
    const scroll=e.target.closest('.nasr-sidebar nav,.nasr-subtabs,.nasr-student-popup');if(!scroll)return;e.stopPropagation();
    const delta=e.deltaY*(e.deltaMode===1?20:e.deltaMode===2?scroll.clientHeight:1);
    if(scroll.matches('.nasr-student-popup')){scroll.scrollTop+=delta;e.preventDefault();}
    else if(scroll.matches('nav') && scroll.scrollHeight>scroll.clientHeight){scroll.scrollTop+=delta;e.preventDefault();}
    else if(scroll.matches('.nasr-subtabs') && scroll.scrollWidth>scroll.clientWidth && !e.deltaX){scroll.scrollLeft-=delta;e.preventDefault();}
  },{passive:false});
  root.addEventListener('touchmove',e=>{if(e.target.closest('.nasr-sidebar,.nasr-subtabs,.nasr-student-popup'))e.stopPropagation();},{passive:true});
  // The print document contains no theme markup, footer hooks or third-party scripts.
  let printing=false;
  function printDocument(title,html,context='',notes='',options={}){
    if(printing){toast('پنجرهٔ چاپ قبلی را ببندید.');return;}
    const p={...pref(),...(options.attendance?{print_paper:'A4',print_orientation:'landscape',print_margin:8}:{})},iframe=document.createElement('iframe');iframe.id='nasr-isolated-print';iframe.title='پیش‌نمایش چاپ';iframe.setAttribute('aria-hidden','true');iframe.style.cssText='position:fixed;left:-10000px;top:0;width:1100px;height:800px;border:0';
    const css=`@font-face{font-family:NasrFont;src:url('${C.assets}nasr-font.woff') format('woff');font-display:swap}*{box-sizing:border-box}body{direction:${options.english?'ltr':'rtl'};margin:0;font-family:${p.font_family},Tahoma,Arial,sans-serif;font-size:${p.print_font_size}px;line-height:1.7;color:#111}h1{font-size:1.65em;margin:0 0 8px}h2,h3{font-size:1.25em;margin:12px 0 6px}p{margin:6px 0;white-space:pre-wrap}small{font-size:.9em}table{width:100%;border-collapse:collapse;table-layout:auto}th,td{border:1px solid #aaa;padding:${p.print_padding}px;text-align:right;overflow-wrap:anywhere;white-space:normal}th{background:#edf0f4}thead{display:table-header-group}tfoot{display:table-row-group;font-weight:900;background:#edf0f4}.nasr-student-grade-term h4{margin:16px 0 6px;font-size:14px;break-after:avoid}.nasr-student-grade-branch{margin-bottom:8px}.nasr-student-grade-table{font-family:Arial,Tahoma,sans-serif;font-size:9px;line-height:1.4}.nasr-student-grade-table th,.nasr-student-grade-table td{text-align:left;padding:3px}.nasr-student-grade-table [data-col=feedback]{white-space:pre-wrap}.nasr-annual-table{font-size:9px;line-height:1.4}.nasr-annual-table th,.nasr-annual-table td{padding:3px 2px}.nasr-annual-table small{display:block}.nasr-annual-table [data-col=term_name]{font-weight:800}.nasr-payroll-report{line-height:1.45}.nasr-payroll-adjustment-report th,.nasr-payroll-adjustment-report td,.nasr-payroll-settlement th,.nasr-payroll-settlement td{padding:3px;font-size:11px}.nasr-payroll-report h3{font-size:1.4em}.nasr-payroll-report h4{margin:12px 0 5px;break-after:avoid}.nasr-payroll-class-table{table-layout:fixed;font-size:max(9px,.82em)}.nasr-payroll-class-table th,.nasr-payroll-class-table td{padding:3px 2px}.nasr-payroll-class-table [data-col=class_name]{font-weight:800}.nasr-payroll-settlement{break-inside:avoid;margin-top:20px}.nasr-payroll-final{font-size:1.15em;font-weight:900;background:#e8f0ec}.nasr-payroll-adjustment-report .nasr-report-table{min-width:0}.nasr-payroll-report .error{border:1px solid #b00020;padding:8px;margin-top:10px}.nasr-teacher-classes-table td[data-col=class_name]{font-size:calc(1em + 2px);font-weight:900}.nasr-attendance-table{direction:ltr}.nasr-attendance-table th,.nasr-attendance-table td{text-align:left}.nasr-report-metadata{display:flex;flex-wrap:wrap;gap:8px 20px;margin:12px 0}.nasr-report-metadata>div{min-width:120px}.nasr-report-metadata span{display:block;color:#555}.nasr-report-metadata strong{display:block}tr{break-inside:avoid}td[dir=ltr]{text-align:left}button,a{font:inherit;color:inherit;text-decoration:none}button{border:0;background:none}footer{margin-top:14px;border-top:1px solid #aaa;padding-top:6px}.nasr-report-summary,.nasr-grade-grid,.nasr-finance-overview{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}.nasr-report-summary>div,.nasr-grade,.nasr-finance-overview>div{border:1px solid #ccc;padding:8px;min-width:100px}.nasr-grade strong,.nasr-finance-overview strong,.nasr-report-summary strong{display:block}.nasr-block{display:block}.nasr-report-print-title{display:none}.nasr-muted{color:#444}.nasr-feedback{border:1px solid #ddd;padding:8px}.nasr-grade small{font-weight:normal}.nasr-table-wrap{overflow:visible}.nasr-comprehensive-report{border:1.5px solid #111;padding:8px;line-height:1.45}.nasr-comprehensive-report h2{text-align:center;font-size:1.35em;margin:0 0 8px}.nasr-comprehensive-head{display:grid;grid-template-columns:1fr 1fr;gap:4px 24px;margin-bottom:8px}.nasr-comprehensive-head>div{display:flex;gap:5px;align-items:baseline}.nasr-comprehensive-head b{white-space:nowrap}.nasr-comprehensive-fees{flex-wrap:wrap}.nasr-comprehensive-fees i{font-style:normal}.nasr-comprehensive-dates{grid-column:1/-1;display:grid!important;grid-template-columns:repeat(3,1fr);gap:12px;border-top:1px solid #111;padding-top:5px}.nasr-comprehensive-table{table-layout:fixed;font-size:max(8px,0.78em);line-height:1.35}.nasr-comprehensive-table th,.nasr-comprehensive-table td{border-color:#111;text-align:center;padding:3px 2px;overflow-wrap:anywhere}.nasr-comprehensive-table th{background:#fff;font-weight:700}.nasr-comprehensive-table :is(th,td):is([data-col=student_name],[data-col=mobile]){font-weight:900}.nasr-comprehensive-table td[data-col=student_name]{text-align:right}.nasr-comprehensive-table td:is([data-col=student_name],[data-col=mobile]){font-size:calc(1em + 2px)}.nasr-comprehensive-class-name strong{font-size:1.35em;font-weight:900;overflow-wrap:anywhere}.nasr-comprehensive-report h2{font-size:1.55em;font-weight:900}.nasr-comprehensive-table [data-col=row_number]{width:3%}.nasr-comprehensive-table [data-col=student_code]{width:7%}.nasr-comprehensive-table [data-col=student_name]{width:20%}.nasr-comprehensive-table [data-col=mobile]{width:14%}.nasr-comprehensive-table [data-col=tuition_amount]{width:7%}.nasr-comprehensive-table [data-col=payment_dates]{width:6%}.nasr-comprehensive-table [data-col=payment_receipt_method]{width:11%}.nasr-comprehensive-table [data-col=book_copy_amount]{width:10%}.nasr-comprehensive-table [data-col=previous_debt]{width:7%}.nasr-comprehensive-table [data-col=snack_stationery_fee]{width:15%}.nasr-comprehensive-blank td{height:29px}${p.print_zebra?'tbody tr:nth-child(even){background:#f3f4f6}':''}.nasr-attendance-sheet{table-layout:fixed;width:100%;font-family:Arial,Tahoma,sans-serif;font-size:9px;line-height:1.25}.nasr-attendance-sheet th,.nasr-attendance-sheet td{text-align:center;padding:3px 1px;white-space:normal;overflow-wrap:normal;border-color:#555;height:24px}.nasr-attendance-sheet [data-col=english_name]{width:24%;text-align:left;font-size:11px;overflow-wrap:anywhere;padding:3px 5px}.nasr-english-report{direction:ltr;text-align:left;font-family:Arial,Tahoma,sans-serif}.nasr-english-report .nasr-section-head{display:block}.nasr-english-report .nasr-section-head button{display:none}.nasr-english-report .nasr-report-metadata{font-size:12px}.nasr-payment-receipt{max-width:700px;margin:0 auto}.nasr-payment-receipt h2,.nasr-payment-receipt h3{text-align:center}.nasr-payment-receipt th{width:32%}.nasr-payment-receipt .error{border:2px solid #b00020;padding:10px;color:#900}.nasr-receipt-amount{font-size:18px;border:1px solid #ccc;padding:14px;margin:12px 0}@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}@page{size:${p.print_paper} ${p.print_orientation};margin:${p.print_margin}mm}`;
    const standard=options.embeddedTitle?'':`<h1>${h(title)}</h1>${p.print_context&&context?`<p>${h(context)}</p>`:''}`;
    iframe.srcdoc=`<!doctype html><html lang="${options.english?'en':'fa'}" dir="${options.english?'ltr':'rtl'}"><head><meta charset="utf-8"><title>${h(title)}</title><style>${css}</style></head><body class="${h(options.className || '')}">${p.print_academy&&!options.receipt?`<h2>${h(S.boot.settings.academy_name)}</h2>`:''}${standard}${p.print_date?`<p>${options.english?'Report date: '+h(new Intl.DateTimeFormat('en-GB',{year:'numeric',month:'short',day:'numeric'}).format(new Date())):'تاریخ گزارش: '+h(date(today()))}</p>`:''}${html}${p.print_notes&&notes?`<p>${h(notes)}</p>`:''}${p.print_footer&&!options.english?`<footer>${h(p.print_footer)}</footer>`:''}</body></html>`;
    printing=true;const cleanup=()=>{printing=false;iframe.remove();};
    iframe.onload=async()=>{try{await iframe.contentDocument.fonts.ready;iframe.contentWindow.addEventListener('afterprint',cleanup,{once:true});iframe.contentWindow.focus();iframe.contentWindow.print();}catch(e){cleanup();toast('پنجرهٔ چاپ باز نشد؛ دوباره تلاش کنید.',true);}};
    document.body.append(iframe);setTimeout(()=>{if(iframe.isConnected)cleanup();},300000);
  }
  function printTable(data,rows,type,context=''){
    if(type==='attendance'){const header=pref().print_context?reportMetadata(data):'';printDocument(data.title,header+reportTable(data,rows),data.metadata?.length?'':context,data.note || '',{attendance:true});return;}
    const selected=pref().print_columns[type];
    const defaults=data.columns.filter(c=>!selected || selected.includes(c.key) || (selected.includes('sessions') && c.type==='attendance')).map(c=>c.key);
    modal('انتخاب ستون‌های چاپ',`<div class="nasr-check-grid">${data.columns.map(c=>`<label class="nasr-check"><input type="checkbox" name="print_column" value="${h(c.key)}" ${defaults.includes(c.key)?'checked':''}>${h(c.label)}</label>`).join('')}</div>`,form=>{
      const keys=[...form.querySelectorAll('[name=print_column]:checked')].map(x=>x.value);if(!keys.length)throw new Error('حداقل یک ستون انتخاب کنید.');closeModal();
      const report={...data,columns:data.columns.filter(c=>keys.includes(c.key))},custom=data.layout==='comprehensive_class';
      const payroll=data.layout==='teacher_pay_detail',studentHistory=data.layout==='student_grades';
      const content=studentHistory?studentGradesReport(report,rows,{metadata:pref().print_context}):payroll?teacherPayReport(report,rows):custom?comprehensiveClassReport(report,rows,{columns:report.columns}):`${pref().print_summary&&data.summary?.length?reportSummary(data):''}${pref().print_context?reportMetadata(data):''}${reportTable(report,rows)}`;
      printDocument(data.title,content,data.metadata?.length?'':context,data.note || '',studentHistory?{embeddedTitle:true,english:true,className:'nasr-student-grade-print'}:payroll?{embeddedTitle:true,className:'nasr-payroll-print'}:custom?{embeddedTitle:true,className:'nasr-comprehensive-print'}:{});
    },'نمایش چاپ / ذخیرهٔ PDF',true);
  }
  function printRoster(){
    const {class:c,enrollments}=S.detail;
    const catalog={student_name:'نام فارسی',english_name:'نام انگلیسی',student_code:'کد',status:'وضعیت',classwork:'Classwork',midterm:'Midterm',final_exam:'Final Exam',total:'Total Score',...(isManager()?{snack_stationery_fee:'خوراکی تحریر',private_fee:'خصوصی',other_fee:'سایر هزینه‌ها',net_fee:'شهریه و هزینه‌ها',balance:'مانده'}:{})};
    const columns=Object.entries(catalog).map(([key,label])=>({key,label,type:['net_fee','balance','snack_stationery_fee','private_fee','other_fee'].includes(key)?'money':['classwork','midterm','final_exam','total','student_code'].includes(key)?'number':'text'}));
    const rows=enrollments.map(e=>({...e,...e.grades,student_name:fullName(e),english_name:englishName(e),status:+e.active?'فعال':'انصراف / بایگانی'}));
    printTable({title:'فهرست زبان‌آموزان کلاس',columns,note:c.notes},rows,'class_roster',`${c.name} · ${c.term_name} · ${c.branch_name || ''} · ${c.schedule || ''}`);
  }
  function printIndividual(id){
    const source=root.querySelector(`[data-report="${Number(id)}"]`);if(!source)return;
    const clone=source.cloneNode(true);clone.querySelectorAll('button,.nasr-report-print-title').forEach(x=>x.remove());
    printDocument('Report Card',clone.outerHTML,'','',{embeddedTitle:true,english:true,className:'nasr-english-report'});
  }

  // Also isolate the portal when a user presses the browser's native Ctrl+P.
  const hiddenPrint=[];
  window.addEventListener('beforeprint',()=>{let node=root;while(node?.parentElement){for(const sibling of node.parentElement.children)if(sibling!==node&&!['SCRIPT','STYLE','LINK'].includes(sibling.tagName)){sibling.classList.add('nasr-outside-print');hiddenPrint.push(sibling);}node=node.parentElement;if(node===document.body)break;}});
  window.addEventListener('afterprint',()=>{hiddenPrint.splice(0).forEach(x=>x.classList.remove('nasr-outside-print'));});

  const sms={config:null,templates:[],options:null,selected:new Set(),campaignId:0,status:'',selection:'all'};
  const smsStatus={queued:'در انتظار ارسال',sending:'در حال ارسال',sent:'پذیرفته‌شده توسط سامانه',failed:'ناموفق',unknown:'نتیجه نامشخص',skipped:'ارسال نشد',cancelled:'لغوشده'};
  const campaignStatus={draft:'پیش‌نمایش؛ تأیید نشده',queued:'صف فعال',paused:'متوقف',cancelled:'لغوشده'};
  const uuid=()=>crypto.randomUUID?.() || 'nasr_'+Date.now()+'_'+Math.random().toString(36).slice(2);
  const tabs=active=>`<nav class="nasr-subtabs" aria-label="بخش‌های پیامک" data-lenis-prevent tabindex="0">${[['new','ارسال جدید'],['templates','قالب‌ها و ارسال خودکار'],['campaigns','صف و گزارش ارسال'],['optouts','فهرست عدم ارسال'],['config','اتصال و تنظیمات']].map(([path,label])=>`<a href="#sms/${path}" class="${path===active?'active':''}">${label}</a>`).join('')}</nav>`;
  async function loadSMS(){[sms.config,sms.templates,sms.options]=await Promise.all([api('sms/config'),api('sms/templates'),api('report-options')]);}
  function queueHealth(config){const q=config.queue;if(!q)return '';return `<div class="nasr-alert" role="status"><strong>وضعیت صف: ${h(q.message)}</strong><p>ساعت تهران: <bdi>${h(q.tehran_time)}</bdi> · ساعت مجاز: <bdi>${h(q.window)}</bdi> · ظرفیت باقی‌ماندهٔ امروز: ${num(q.remaining_today)}</p><p>در انتظار: ${num(q.waiting)} · آمادهٔ پردازش: ${num(q.due)} · آخرین پردازش: ${q.last_tick?date(q.last_tick,true):'هنوز اجرا نشده'}</p>${q.cron_warning?`<p>${h(q.cron_warning)}</p>`:''}${config.last_error?`<p class="error">${h(config.last_error)}</p>`:''}</div>`;}
  async function monitorSMS(){
    if(!isManager() || S.view!=='sms' || document.hidden || sms.pumping || root.querySelector('#nasr-dialog[open]') || root.querySelector('form[data-saving]'))return;
    sms.pumping=true;const hash=location.hash;
    try{let config=await api('sms/config');if(location.hash!==hash)return;sms.config=config;
      const q=config.queue;let result=null;if(config.settings.enabled && ((!q.block_code && (q.due || q.pending_events)) || q.expired))result=await api('sms/process',{});
      if(location.hash!==hash)return;if(result)config={...config,queue:result.queue,last_error:result.last_error};
      const box=root.querySelector('#nasr-sms-queue-health');if(box)box.innerHTML=queueHealth(config);
      if(result && !root.querySelector('#nasr-dialog[open]') && (S.routeId==='campaigns' || (S.routeId==='campaign' && sms.current?.campaign?.state!=='draft')))await render();
    }catch(e){const box=root.querySelector('#nasr-sms-queue-health');if(location.hash===hash && box)box.innerHTML=`<p class="nasr-alert error">پردازش خودکار صفحه انجام نشد: ${h(e.message)} برای بررسی «پردازش صف اکنون» را بزنید.</p>`;}
    finally{sms.pumping=false;}
  }
  setInterval(monitorSMS,10000);
  function scopeFields(t={}){return select('شعبه','branch_id',t.branch_id??S.branchId,A.branchOptions())+select('ترم','term_id',t.term_id || '',[['','همهٔ ترم‌های فعال'],...sms.options.terms.filter(t=>!t.deleted_at).map(t=>[t.id,`${t.name} · ${t.branch_name || 'بدون شعبه'}`])])+select('کلاس','class_id',t.class_id || '',[['','همهٔ کلاس‌های فعال'],...sms.options.classes.filter(c=>!c.deleted_at).map(c=>[c.id,`${c.name} · ${sms.options.terms.find(t=>+t.id===+c.term_id)?.name || ''}`])]);}
  async function smsPage(tab='new',id=''){
    await loadSMS();const sub=tab || 'new';let body='';
    if(sub==='config')body=configPage();
    else if(sub==='templates')body=templatesPage();
    else if(sub==='optouts')body=await optoutPage();
    else if(sub==='campaign')body=await campaignPage(id);
    else if(sub==='campaigns')body=await campaignsPage();
    else body=newPage();
    return sectionHead('ارسال پیامک','')+tabs(sub==='campaign'?'campaigns':sub)+`<div id="nasr-sms-queue-health">${queueHealth(sms.config)}</div>`+body;
  }
  function configPage(){const s=sms.config.settings;
    return `<section class="nasr-panel"><form id="nasr-sms-config"><h3>اتصال به ملی‌پیامک</h3><div class="nasr-form-grid">${check('فعال بودن ارسال پیامک','enabled',s.enabled)}${field('نام کاربری ملی‌پیامک','username',s.username,{dir:'ltr',autocomplete:'off'})}${field('API Key وب‌سرویس','secret','',{type:'password',dir:'ltr',autocomplete:'new-password',help:s.has_secret?'کلید ذخیره شده است؛ برای حفظ آن این خانه را خالی بگذارید.':'کلید وب‌سرویس را از پنل ملی‌پیامک دریافت کنید.'})}${check('پاک کردن کلید ذخیره‌شده','clear_secret',false)}${field('شماره خط فرستنده','sender',s.sender,{dir:'ltr',mode:'numeric',help:'برای ارسال متنی لازم است؛ پترن از خط خدماتی همان پترن استفاده می‌کند.'})}${field('تعداد پیام در هر نوبت پردازش','batch_size',s.batch_size,{mode:'numeric',help:'۱ تا ۲۰ پیام؛ تعداد واقعی تابع زمان پاسخ وب‌سرویس است.'})}${field('سقف روزانهٔ پیام','daily_limit',s.daily_limit,{mode:'numeric'})}${field('شروع ساعت مجاز ارسال','send_from',s.send_from,{mode:'numeric',help:'۰ تا ۲۳، به وقت تهران'})}${field('پایان ساعت مجاز ارسال','send_until',s.send_until,{mode:'numeric',help:'۱ تا ۲۴؛ مثلاً ۲۱ یعنی تا قبل از ساعت ۲۱'})}${field('مهلت پیام در صف (ساعت)','expire_hours',s.expire_hours,{mode:'numeric',help:'۱ تا ۱۶۸ ساعت پس از زمان برنامه‌ریزی؛ یادآوری کلاس با شروع کلاس منقضی می‌شود.'})}${field('فاصلهٔ جلوگیری از پیام یکسان (ساعت)','dedupe_hours',s.dedupe_hours,{mode:'numeric',help:'صفر برای غیرفعال کردن؛ پیام یکسان به یک شماره دوباره ارسال نمی‌شود.'})}${field('امضای انتهای پیام متنی','signature',s.signature,{wide:true,maxlength:160})}${check('پیگیری خودکار وضعیت تحویل','auto_delivery',s.auto_delivery)}</div><button type="submit" class="nasr-button primary">ذخیرهٔ اتصال و تنظیمات</button></form>
    <div class="nasr-settings-group"><h3>بررسی اتصال و صف</h3><div class="nasr-actions">${button('استعلام اعتبار','sms-credit','','soft')}${button('ارسال یک پیامک آزمایشی','sms-test','','soft')}${button('پردازش صف اکنون','sms-process','','soft')}</div><div id="nasr-sms-credit" role="status"></div><p>آخرین پردازش: ${sms.config.last_tick?date(sms.config.last_tick,true):'هنوز اجرا نشده'}</p>${sms.config.last_error?`<p class="nasr-alert error">${h(sms.config.last_error)}</p>`:''}${(sms.config.event_errors||[]).map(e=>`<p class="nasr-alert error">${h(sms.config.events[e.event_name])} · ${date(e.created_at,true)}: ${h(e.error_message)}</p>`).join('')}${sms.config.cron_disabled?'<p class="nasr-alert">زمان‌بند داخلی غیرفعال است.</p>':''}<p><a href="https://www.melipayamak.com/api/sendsimplesms2/" target="_blank" rel="noopener noreferrer">راهنمای رسمی اتصال و خطاهای ملی‌پیامک</a></p></div></section>`;
  }
  function templatesPage(){return `<section class="nasr-panel">${sectionHead('قالب‌های پیامک','',button('قالب جدید','sms-template','','primary','plus'))}<div class="nasr-table-wrap"><table><thead><tr><th>نام و کاربرد</th><th>رویداد</th><th>گیرنده</th><th>روش</th><th>وضعیت</th><th></th></tr></thead><tbody>${sms.templates.map(t=>`<tr><td><strong>${h(t.name)}</strong><small class="nasr-block">${h(sms.config.purposes[t.purpose])}</small></td><td>${h(sms.config.events[t.event])}</td><td>${h({student:'زبان‌آموز',family:'خانواده',both:'هر دو'}[t.audience])}</td><td>${t.mode==='pattern'?`پترن ${h(t.body_id)}`:'متنی'}</td><td>${+t.active?'فعال':'غیرفعال'}</td><td>${button('ویرایش','sms-template',t.id,'text','edit')}${button('تکثیر','sms-clone',t.id,'text')}</td></tr>`).join('')}</tbody></table></div></section>`;}
  function templateModal(id,clone=false){const old=sms.templates.find(x=>+x.id===+id);const t=old?{...old,...(clone?{id:0,name:old.name+' (کپی)',event:'manual'}:{})}:{name:'',purpose:'general',event:'manual',mode:'text',content:'',params:'',body_id:'',audience:'student',active:1,branch_id:'',term_id:'',class_id:'',hours_before:2,debt_after_days:7,repeat_days:7};
    const body=`<div class="nasr-form-grid">${field('نام قالب','name',t.name,{required:true,maxlength:150})}${select('کاربرد پیامک','purpose',t.purpose,Object.entries(sms.config.purposes))}${select('زمان / رویداد ارسال','event',t.event,Object.entries(sms.config.events))}${select('گیرنده','audience',t.audience,[['student','خود زبان‌آموز'],['family','خانواده‌های مرتبط'],['both','زبان‌آموز و خانواده‌ها']])}${select('روش ارسال','mode',t.mode,[['text','پیام متنی از خط شما'],['pattern','پترن خدماتی تأییدشده']])}${check('قالب فعال باشد','active',+t.active)}${scopeFields(t)}${field('متن پیام / متن مرجع پترن','content',t.content,{area:true,wide:true,help:'در حالت پترن، متن واقعی از قالب تأییدشدهٔ ملی‌پیامک می‌آید؛ متن مرجع را دقیقاً مطابق آن بنویسید.'})}<div class="wide nasr-sms-vars">${Object.entries(sms.config.variables).map(([k,label])=>`<button type="button" class="nasr-button text" data-action="sms-variable" data-id="${h(k)}" title="${h(label)}"><bdi>{${h(k)}}</bdi> · ${h(label)}</button>`).join('')}</div><div class="wide nasr-form-grid" data-sms-pattern ${t.mode!=='pattern'?'hidden':''}>${field('کد پترن (bodyId)','body_id',t.body_id,{mode:'numeric',dir:'ltr'})}${field('پارامترهای پترن به ترتیب','params',t.params,{area:true,wide:true,help:'هر مقدار در یک خط؛ مثلاً {full_name} در خط اول و {balance} در خط دوم. ترتیب باید با پنل ملی‌پیامک یکسان باشد.'})}</div><div class="wide nasr-form-grid" data-sms-reminders>${field('یادآوری کلاس / آزمون چند ساعت قبل؟','hours_before',t.hours_before,{mode:'numeric',help:'۱ تا ۱۶۸؛ مبنای آزمون آغاز روز آزمون است، چون ساعت آزمون در ترم ثبت نمی‌شود.'})}${field('شروع یادآوری شهریه چند روز پس از شروع ترم؟','debt_after_days',t.debt_after_days,{mode:'numeric'})}${field('تکرار یادآوری شهریه هر چند روز؟','repeat_days',t.repeat_days,{mode:'numeric'})}</div></div>`;
    modal(t.id?'ویرایش قالب':'قالب جدید',body,async form=>{const d=formData(form);d.version=t.version;const result=await api('sms/templates'+(t.id?'/'+t.id:''),d);closeModal();toast(result.message);await render();},'ذخیرهٔ قالب',true);
  }
  function newPage(){return `<section class="nasr-panel"><form id="nasr-sms-preview" data-request-key="${uuid()}"><h3>ارسال تکی، گروهی یا زمان‌بندی‌شده</h3><div class="nasr-form-grid">${field('عنوان این ارسال','title','',{maxlength:190,help:'برای تشخیص در گزارش ارسال'})}${select('قالب پیامک','template_id','',[['','قالب را انتخاب کنید'],...sms.templates.filter(t=>+t.active).map(t=>[t.id,t.name])])}${scopeFields()}${select('یک فرد ثبت‌نام‌شده (اختیاری)','student_id','',[['','همهٔ افراد محدودهٔ انتخابی'],...sms.options.people.filter(p=>['student','teacher'].includes(p.kind)&&p.student_code&&!p.deleted_at).map(p=>[p.user_id,`${fullName(p)} · ${p.kind==='teacher'?'معلم · ':''}${p.student_code}`])])}${check('فقط افراد بدون هیچ پرداخت موفق','unpaid',false)}${field('تاریخ ارسال (اختیاری)','send_date','',{date:true,dir:'ltr',help:'خالی: پس از تأیید و در ساعات مجاز ارسال'})}${field('ساعت ارسال به وقت تهران','send_time','',{dir:'ltr',placeholder:'16:30'})}<div class="wide" id="nasr-sms-template-detail"></div></div><button type="submit" class="nasr-button primary">ساخت پیش‌نمایش مخاطبان و متن</button></form></section>`;}
  function templatePreview(form){const t=sms.templates.find(x=>+x.id===+form.elements.template_id.value);const box=form.querySelector('#nasr-sms-template-detail');if(!t){box.innerHTML='';return;}
    box.innerHTML=`<p>گیرنده: ${h({student:'زبان‌آموز',family:'خانواده‌های مرتبط',both:'زبان‌آموز و خانواده'}[t.audience])} · ${h(sms.config.purposes[t.purpose])}</p><pre class="nasr-sms-text">${h(t.content)}</pre>${t.mode==='pattern'?`<p>پترن خدماتی ${h(t.body_id)}؛ پارامترها به ترتیب:</p><pre class="nasr-sms-text">${h(t.params)}</pre>`:''}<div class="nasr-form-grid">${t.purpose==='attendance'?field('شماره جلسهٔ ثبت‌شده','session_no','',{mode:'numeric',required:true})+select('فقط افراد با وضعیت ثبت‌شدهٔ','attendance_status','absent',[['absent','غایب'],['late','تأخیر'],['present','حاضر'],['excused','موجه']],'کلاس مشخص را انتخاب کنید؛ تاریخ از حضور و غیاب ذخیره‌شده خوانده می‌شود.'):''}${t.purpose==='exam'?field('تاریخ آزمون','exam_date','',{date:true,dir:'ltr',required:true})+field('عنوان آزمون','exam_name','آزمون',{required:true}):''}${t.purpose==='payment'?field('شناسهٔ پرداخت موفق','payment_id','',{mode:'numeric',required:true,help:'شناسه در تاریخچهٔ ثبت پرداخت موجود است. برای رسید خودکار، رویداد «پس از پرداخت موفق» را روی قالب تنظیم کنید.'}):''}</div>`;
    for(const k of ['branch_id','term_id','class_id'])if(t[k]!=='' && form.elements[k])form.elements[k].value=t[k];
  }
  // The row supplies the student and class; template selection never widens this scope.
  async function studentSMS(id,el){
    if(!isManager())throw new Error('ارسال پیامک فقط برای مدیر قابل دسترسی است.');
    const detail=S.detail,c=detail?.class,e=detail?.enrollments.find(x=>+x.id===+id),route=location.hash;
    if(!e || !+e.student_id || !+c?.id)throw new Error('زبان‌آموز یا کلاس پیدا نشد؛ صفحه را تازه کنید.');
    el.disabled=true;
    try{
      const [config,templates]=await Promise.all([api('sms/config'),api('sms/templates')]);
      if(location.hash!==route || S.detail!==detail)return;
      sms.config=config;sms.templates=templates;
      const available=templates.filter(t=>+t.active && [['class_id',c.id],['term_id',c.term_id],['branch_id',c.branch_id || 0]].every(([k,v])=>t[k]==='' || +t[k]===+v));
      if(!available.length)return modal('ارسال پیامک برای '+fullName(e),'<p>قالب فعال متناسب با این کلاس وجود ندارد.</p>'+link('مدیریت قالب‌های پیامک','sms/templates','primary'),null);
      const scope=`<p><strong>${h(fullName(e))}</strong> · کد ${num(e.student_code)}</p><p class="nasr-muted">${h(c.name)} · ${h(c.term_name)} · ${h(c.branch_name || 'شعبه تعیین نشده')}</p>`;
      let requestKey=uuid(),lastPayload='';
      modal('ارسال پیامک برای '+fullName(e),scope+(!config.settings.enabled?'<p class="nasr-alert">ارسال پیامک غیرفعال است.</p>':'')+`<fieldset data-student-sms-fields style="border:0;padding:0;margin:0;min-width:0"><div class="nasr-form-grid">${select('نوع پیامک','student_sms_purpose','',[['','نوع پیامک را انتخاب کنید'],...Object.entries(config.purposes).filter(([key])=>available.some(t=>t.purpose===key))])}${select('قالب پیامک','template_id','',[['','ابتدا نوع پیامک را انتخاب کنید']])}<div class="wide" id="nasr-sms-template-detail"></div></div></fieldset>`,async form=>{
        const data=formData(form),template=available.find(t=>+t.id===+data.template_id);
        if(!template)throw new Error('نوع و قالب پیامک را انتخاب کنید.');
        const payload={...data,student_id:+e.student_id,class_id:+c.id,term_id:+c.term_id,branch_id:+c.branch_id || 0,title:('ارسال دستی · '+fullName(e)+' · '+c.name+' · '+template.name).slice(0,180)};
        const signature=JSON.stringify(payload);if(lastPayload && lastPayload!==signature)requestKey=uuid();lastPayload=signature;
        const fields=form.querySelector('[data-student-sms-fields]');fields.disabled=true;
        try{
          const preview=await api('sms/preview',{...payload,request_key:requestKey});
          const report=await studentSMSReport(preview.id);
          if(!form.isConnected || location.hash!==route)return;
          if(report.campaign.state!=='draft')return studentSMSResult(report);
          modal('بررسی و ارسال پیامک',scope+`<p>${num(report.items.length)} گیرنده · ${h(template.name)}</p>`+studentSMSMessages(report.items,true)+(preview.skipped?`<p class="nasr-alert">${num(preview.skipped)} مورد کنار گذاشته شد. ${h((preview.reasons || []).join(' '))}</p>`:'')+''+check('گیرنده‌ها و متن را بررسی کرده‌ام و ارسال پیامک را تأیید می‌کنم.','confirm',false),async confirmForm=>{
            if(!formData(confirmForm).confirm)throw new Error('ارسال پیامک را تأیید کنید.');
            // Recover a response lost after a successful queue action without sending again.
            const current=await studentSMSReport(preview.id);
            if(!confirmForm.isConnected || location.hash!==route)return;
            if(current.campaign.state==='draft')await api('sms/campaigns/'+preview.id,{action:'queue',confirm:true,process_now:true,selection:'all'});
            const result=await studentSMSReport(preview.id);
            if(confirmForm.isConnected && location.hash===route)studentSMSResult(result);
          },'ارسال پیامک');
        }finally{fields.disabled=false;}
      },'نمایش متن نهایی و گیرنده');
      const form=root.querySelector('#nasr-modal-form');form.dataset.studentSms='1';
      form.elements.template_id.required=true;form.elements.student_sms_purpose.required=true;
      form.elements.student_sms_purpose.addEventListener('change',()=>{
        const list=available.filter(t=>t.purpose===form.elements.student_sms_purpose.value);
        form.elements.template_id.innerHTML='<option value="">قالب را انتخاب کنید</option>'+list.map(t=>`<option value="${+t.id}">${h(t.name)}</option>`).join('');
        if(list.length===1)form.elements.template_id.value=list[0].id;
        updateDetail();
      });
      const updateDetail=()=>{
        templatePreview(form);
        const template=available.find(t=>+t.id===+form.elements.template_id.value);
        if(template?.purpose==='payment'){
          const input=form.querySelector('[name=payment_id]');
          const payments=(e.payments || []).filter(p=>p.status==='success' && !p.voided_at);
          if(input){const picker=document.createElement('select');picker.name='payment_id';picker.required=true;picker.innerHTML='<option value="">پرداخت همین زبان‌آموز در این کلاس را انتخاب کنید</option>'+payments.map(p=>`<option value="${+p.id}">#${num(p.id)} · ${num(p.amount)} ${h(S.boot.settings.currency)} · ${h(dateInput(p.paid_on))}</option>`).join('');input.replaceWith(picker);const help=picker.closest('label')?.querySelector('small');if(help)help.remove();}
        }
      };
      form.elements.template_id.addEventListener('change',updateDetail);
    }finally{el.disabled=false;}
  }
  async function classSMS(id,el){
    if(!isManager())throw new Error('ارسال پیامک فقط برای مدیر و منشی قابل دسترسی است.');
    const route=location.hash;el.disabled=true;
    try{
      const detail=+S.detail?.class?.id===+id?S.detail:await api('classes/'+Number(id)),c=detail.class;
      if(!c||!+c.active)throw new Error('برای ارسال پیامک، کلاس فعال را انتخاب کنید.');
      const [config,templates]=await Promise.all([api('sms/config'),api('sms/templates')]);
      if(location.hash!==route)return;
      sms.config=config;sms.templates=templates;
      const available=templates.filter(t=>+t.active&&[['class_id',c.id],['term_id',c.term_id],['branch_id',c.branch_id||0]].every(([k,v])=>t[k]===''||+t[k]===+v));
      if(!available.length)return modal('اطلاع‌رسانی پیامکی کلاس','<p>قالب فعال متناسب با این کلاس وجود ندارد.</p>'+link('مدیریت قالب‌های پیامک','sms/templates','primary'),null);
      const students=detail.enrollments.filter(e=>+e.active&&+e.student_id);
      if(!students.length)return modal('اطلاع‌رسانی پیامکی کلاس','<p>زبان‌آموز فعال قابل انتخابی در این کلاس وجود ندارد.</p>',null);
      const scope=`<p><strong>${h(c.name)}</strong> · ${h(c.term_name)} · ${h(c.branch_name||'شعبه تعیین نشده')}</p>`;
      let requestKey=uuid(),lastPayload='';
      modal('اطلاع‌رسانی پیامکی کلاس',scope+(!config.settings.enabled?'<p class="nasr-alert">ارسال پیامک غیرفعال است.</p>':'')+`<fieldset data-class-sms-fields class="nasr-sms-fields"><div class="nasr-form-grid">${select('قالب پیامک','template_id','',[['','قالب را انتخاب کنید'],...available.map(t=>[t.id,t.name])])}<div class="wide" id="nasr-sms-template-detail"></div></div><section data-class-sms-roster hidden><h3>انتخاب زبان‌آموزان</h3><div class="nasr-class-sms-tools"><input type="search" data-class-sms-search aria-label="جست‌وجوی زبان‌آموزان این کلاس" placeholder="نام یا کد زبان‌آموزی"><label class="nasr-check"><input type="checkbox" data-class-sms-all>انتخاب همهٔ نتایج</label><button type="button" class="nasr-button text" data-class-sms-clear>لغو انتخاب‌ها</button></div><div class="nasr-class-sms-list">${students.map(e=>`<label class="nasr-class-sms-person" data-key="${h(fullName(e)+' '+englishName(e)+' '+e.student_code)}"><input type="checkbox" data-class-sms-enrollment value="${+e.id}" aria-label="انتخاب ${h(fullName(e))}"><span><strong>${h(fullName(e))}</strong><small>کد ${num(e.student_code)}</small></span></label>`).join('')}</div><p data-class-sms-count role="status" aria-live="polite"></p></section></fieldset>`,async form=>{
        const data=formData(form),template=available.find(t=>+t.id===+data.template_id);
        const ids=[...form.querySelectorAll('[data-class-sms-enrollment]:checked')].map(cb=>+cb.value);
        if(!template)throw new Error('قالب پیامک را انتخاب کنید.');
        if(!ids.length)throw new Error('حداقل یک زبان‌آموز را انتخاب کنید.');
        if(template.purpose==='payment'&&ids.length!==1)throw new Error('برای قالب رسید پرداخت، فقط زبان‌آموز مربوط به همان پرداخت را انتخاب کنید.');
        const payload={...data,enrollment_ids:ids,class_id:+c.id,term_id:+c.term_id,branch_id:+c.branch_id||0,title:('پیامک کلاس · '+c.name+' · '+template.name).slice(0,180)};
        const signature=JSON.stringify(payload);if(lastPayload&&lastPayload!==signature)requestKey=uuid();lastPayload=signature;
        const fields=form.querySelector('[data-class-sms-fields]');fields.disabled=true;
        try{
          const preview=await api('sms/preview',{...payload,request_key:requestKey}),report=await studentSMSReport(preview.id);
          if(!form.isConnected||location.hash!==route)return;
          if(report.items.some(m=>!ids.includes(+m.enrollment_id)))throw new Error('گیرنده‌های پیش‌نمایش با انتخاب شما مطابقت ندارند؛ دوباره تلاش کنید.');
          if(!report.items.length)throw new Error('گیرندهٔ قابل ارسال برای انتخاب شما وجود ندارد.');
          if(report.items.length>5000)throw new Error('تعداد گیرنده‌ها بیش از ۵۰۰۰ است؛ تعداد زبان‌آموزان انتخاب‌شده را کاهش دهید.');
          if(report.campaign.state!=='draft')return classSMSResult(report,ids,route);
          const represented=new Set(report.items.map(m=>+m.enrollment_id));
          modal('بررسی و ارسال پیامک گروهی',scope+`<p>${num(represented.size)} زبان‌آموز · ${num(report.items.length)} گیرنده · ${h(template.name)}</p>`+studentSMSMessages(report.items,true)+(represented.size<ids.length?'<p class="nasr-alert">برای برخی از انتخاب‌شده‌ها گیرنده یا پیام قابل ارسال وجود ندارد.</p>':'')+(preview.skipped?`<p class="nasr-alert">${num(preview.skipped)} مورد کنار گذاشته شد. ${h((preview.reasons||[]).join(' '))}</p>`:'')+check('متن و گیرنده‌های انتخاب‌شده را بررسی کرده‌ام و ارسال پیامک را تأیید می‌کنم.','confirm',false),async confirmForm=>{
            if(!formData(confirmForm).confirm)throw new Error('ارسال پیامک را تأیید کنید.');
            const current=await studentSMSReport(preview.id);
            if(!confirmForm.isConnected||location.hash!==route)return;
            if(current.items.some(m=>!ids.includes(+m.enrollment_id)))throw new Error('مخاطبان این ارسال تغییر کرده‌اند؛ پیش‌نمایش تازه بگیرید.');
            if(current.campaign.state==='draft')await api('sms/campaigns/'+preview.id,{action:'queue',confirm:true,process_now:true,selection:'selected',ids:report.items.map(m=>+m.id)});
            const result=await studentSMSReport(preview.id);
            if(confirmForm.isConnected&&location.hash===route)classSMSResult(result,ids,route);
          },'ارسال پیامک');
        }finally{fields.disabled=false;}
      },'نمایش متن نهایی و گیرنده‌ها',true);
      const form=root.querySelector('#nasr-modal-form'),roster=form.querySelector('[data-class-sms-roster]'),all=form.querySelector('[data-class-sms-all]');
      const boxes=()=>[...form.querySelectorAll('[data-class-sms-enrollment]')],visible=()=>boxes().filter(cb=>!cb.closest('label').hidden);
      const sync=()=>{const selected=boxes().filter(cb=>cb.checked),shown=visible();form.querySelector('[data-class-sms-count]').textContent=`انتخاب‌شده: ${num(selected.length)} از ${num(students.length)} زبان‌آموز`;
        all.disabled=!shown.length;all.checked=!!shown.length&&shown.every(cb=>cb.checked);all.indeterminate=shown.some(cb=>cb.checked)&&!all.checked;
        form.querySelector('[type=submit]').disabled=!form.elements.template_id.value||!selected.length;
      };
      form.elements.template_id.required=true;
      form.elements.template_id.addEventListener('change',()=>{boxes().forEach(cb=>cb.checked=false);templatePreview(form);roster.hidden=!form.elements.template_id.value;sync();});
      form.addEventListener('change',event=>{if(event.target.matches('[data-class-sms-enrollment]'))sync();});
      all.addEventListener('change',()=>{visible().forEach(cb=>cb.checked=all.checked);sync();});
      form.querySelector('[data-class-sms-clear]').addEventListener('click',()=>{boxes().forEach(cb=>cb.checked=false);sync();});
      const normalize=value=>String(value).normalize('NFKC').replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).toLocaleLowerCase();
      form.querySelector('[data-class-sms-search]').addEventListener('input',event=>{const q=normalize(event.target.value.trim());form.querySelectorAll('.nasr-class-sms-person').forEach(row=>row.hidden=!normalize(row.dataset.key).includes(q));sync();});sync();
    }finally{el.disabled=false;}
  }
  function classSMSResult(report,ids,route){
    modal('نتیجهٔ پیامک گروهی','<p data-class-sms-progress role="status"></p><div data-class-sms-result></div>'+link('مشاهده و پیگیری ارسال','sms/campaign/'+report.campaign.id,'primary'),null);
    const dialog=root.querySelector('#nasr-dialog'),box=dialog.querySelector('[data-class-sms-result]'),progress=dialog.querySelector('[data-class-sms-progress]');let previous='',unchanged=0,steps=0;
    const alive=()=>dialog.isConnected&&dialog.open&&location.hash===route;
    const show=()=>{box.innerHTML=studentSMSMessages(report.items);const sent=report.items.filter(m=>m.status==='sent').length,waiting=report.items.filter(m=>m.status==='queued'||m.status==='sending').length;progress.textContent=`پذیرفته‌شده: ${num(sent)} · در انتظار: ${num(waiting)} · کل: ${num(report.items.length)}`;};
    const advance=async()=>{
      if(!alive())return;
      if(report.items.some(m=>!ids.includes(+m.enrollment_id))){progress.textContent='گیرنده‌ها با انتخاب شما مطابقت ندارند؛ گزارش ارسال را بررسی کنید.';return;}
      show();
      if(report.campaign.state!=='queued'||report.queue?.block_code||!report.items.some(m=>m.status==='queued')||steps++>=5000)return;
      const fingerprint=JSON.stringify(report.items.map(m=>[m.id,m.status,m.attempts]));unchanged=fingerprint===previous?unchanged+1:0;previous=fingerprint;if(unchanged>=3)return;
      try{
        await api('sms/campaigns/'+report.campaign.id,{action:'process',process_now:true});
        if(!alive())return;report=await studentSMSReport(report.campaign.id);if(alive())setTimeout(advance,500);
      }catch(error){if(alive()){progress.textContent='پیگیری ارسال متوقف شد: '+error.message;}}
    };show();setTimeout(advance,500);
  }
  async function studentSMSReport(id){
    const report=await api('sms/campaigns/'+Number(id));
    for(let page=2;page<=report.pages;page++){const next=await api('sms/campaigns/'+Number(id),undefined,{page});report.items.push(...next.items);}
    return report;
  }
  function studentSMSMessages(items,preview=false){return items.map(m=>`<section class="nasr-student-sms-message"><strong>${h(m.recipient_name)}</strong><div dir="ltr">${h(m.recipient)}</div><pre class="nasr-sms-text">${h(m.content)}</pre>${m.mode==='pattern'?`<p>متن مرجع پترن ${h(m.body_id)}</p><pre class="nasr-sms-text">${h(JSON.parse(m.params).join(' | '))}</pre>`:''}${preview?'':`<p><strong>${h(smsStatus[m.status] || m.status)}</strong></p>${m.rec_id?`<p>شناسهٔ پیگیری: <bdi>${h(m.rec_id)}</bdi></p>`:''}${m.waiting_reason || m.error_message?`<p class="nasr-alert">${h(m.waiting_reason || m.error_message)}</p>`:''}`}</section>`).join('');}
  function studentSMSResult(report){modal('نتیجهٔ درخواست پیامک',studentSMSMessages(report.items)+``+link('مشاهده و پیگیری ارسال','sms/campaign/'+report.campaign.id,'primary'),null);}
  async function campaignsPage(){const res=await api('sms/campaigns',undefined,{page:S.page});return `<section class="nasr-panel">${sectionHead('صف و گزارش ارسال','',button('تازه‌سازی','retry','','text')+button('پردازش صف اکنون','sms-process','','soft'))}${res.items.length?`<div class="nasr-table-wrap"><table><thead><tr><th>عنوان</th><th>وضعیت</th><th>زمان ارسال</th><th>کل</th><th>پذیرفته</th><th>در صف</th><th>خطا / نامشخص</th><th></th></tr></thead><tbody>${res.items.map(c=>`<tr><td>${h(c.title)}<small class="nasr-block">${c.source==='auto'?'خودکار':c.source==='test'?'آزمایشی':'دستی'} · #${num(c.id)}</small></td><td>${h(campaignStatus[c.state])}${c.state==='queued'&&!+c.waiting?'<small class="nasr-block">صف این مجموعه تمام شده</small>':''}</td><td>${date(c.scheduled_at,true)}</td><td>${num(c.total)}</td><td>${num(c.sent)}</td><td>${num(c.waiting)}</td><td>${num(c.problems)}</td><td>${link('مشاهده',`sms/campaign/${c.id}`,'text')}</td></tr>`).join('')}</tbody></table></div>${pager(res)}`:empty('هنوز ارسالی ساخته نشده','')}</section>`;}
  async function campaignPage(id){if(sms.campaignId!==+id){sms.campaignId=+id;sms.selected.clear();sms.selection='all';sms.status='';}const res=await api('sms/campaigns/'+Number(id),undefined,{page:S.page,status:sms.status});sms.current=res;
    if(sms.campaignId!==+id){sms.campaignId=+id;sms.selected.clear();sms.selection='all';sms.status='';}
    const c=res.campaign;const draft=c.state==='draft';
    return `<section class="nasr-panel">${sectionHead(c.title,`${campaignStatus[c.state]} · زمان برنامه‌ریزی: ${date(c.scheduled_at,true)}`,button('تازه‌سازی','retry','','text')+button('خروجی CSV','sms-export',id,'text'))}<div class="nasr-report-summary">${res.counts.map(x=>`<div><span>${h(smsStatus[x.status])}</span><strong>${num(x.count)}</strong></div>`).join('')}</div>
    ${draft?`${select('انتخاب مخاطبان','sms_selection',sms.selection,[['all','همهٔ مخاطبان این پیش‌نمایش'],['selected','فقط ردیف‌هایی که انتخاب می‌کنم']])}<p id="nasr-sms-selected">انتخاب دستی: ${num(sms.selected.size)} نفر</p>`:select('فیلتر وضعیت پیام','sms_status',sms.status,[['','همه'],...Object.entries(smsStatus)])}<div class="nasr-actions">${draft?button('تأیید مخاطبان و ارسال','sms-queue',id,'primary'):''}${c.state==='queued'?button('پردازش صف اکنون','sms-process','','soft')+button('توقف صف','sms-pause',id,'soft'):''}${c.state==='paused'?button('ادامهٔ صف','sms-resume',id,'primary'):''}${c.state!=='cancelled'?button('لغو پیام‌های باقی‌مانده','sms-cancel',id,'text danger'):''}</div>
    <div class="nasr-table-wrap"><table><thead><tr>${draft?'<th>انتخاب</th>':''}<th>گیرنده</th><th>متن نهایی</th><th>وضعیت ارسال و تحویل</th><th>پیگیری</th></tr></thead><tbody>${res.items.map(m=>`<tr>${draft?`<td><input type="checkbox" aria-label="انتخاب ${h(m.recipient_name)}" data-sms-recipient="${m.id}" ${sms.selected.has(+m.id)?'checked':''}></td>`:''}<td>${h(m.recipient_name)}<small class="nasr-block" dir="ltr">${h(m.recipient)}</small></td><td class="nasr-sms-message-cell"><pre class="nasr-sms-text">${h(m.content)}</pre>${m.mode==='pattern'?`<small>متن مرجع پترن ${h(m.body_id)}</small><pre class="nasr-sms-text">${h(JSON.parse(m.params).join(' | '))}</pre>`:''}<small>${num(m.content.length)} نویسه؛ هزینه تابع تعرفه و تعداد بخش‌های ملی‌پیامک است.</small></td><td>${draft?'پیش‌نمایش':h(smsStatus[m.status])}${m.waiting_reason?`<p class="nasr-alert">${h(m.waiting_reason)}</p>`:''}<small class="nasr-block">تعداد تلاش ارسال: ${num(m.attempts)}</small><small class="nasr-block">${h(m.delivery_text || '')}</small>${m.error_message?`<p class="nasr-alert error">${h(m.error_message)}</p>`:''}${m.rec_id?`<bdi>${h(m.rec_id)}</bdi>`:''}</td><td>${m.status==='sent'?button('بررسی تحویل','sms-delivery',m.id,'text'):''}${['failed','unknown'].includes(m.status)&&['queued','paused'].includes(c.state)?button('تلاش مجدد','sms-retry',m.id,'text'):''}${m.sent_at?date(m.sent_at,true):''}</td></tr>`).join('')}</tbody></table></div>${pager(res)}</section>`;
  }
  async function optoutPage(){const rows=await api('sms/optouts');return `<section class="nasr-panel"><h3>شماره‌هایی که پیامک دریافت نکنند</h3><form id="nasr-sms-optout"><div class="nasr-form-grid">${field('شماره همراه','phone','',{mode:'tel',dir:'ltr',required:true})}${field('توضیح','note','',{maxlength:300})}</div><button type="submit" class="nasr-button primary">افزودن به فهرست عدم ارسال</button></form><div class="nasr-table-wrap"><table><thead><tr><th>شماره</th><th>توضیح</th><th></th></tr></thead><tbody>${rows.map(r=>`<tr><td dir="ltr">${h(r.phone)}</td><td>${h(r.note)}</td><td>${button('حذف از فهرست','sms-optout-remove',r.phone,'text')}</td></tr>`).join('')}</tbody></table></div></section>`;}
  async function smsAction(action,id,el){
    if(action==='sms-class')return classSMS(id,el);
    if(action==='sms-student')return studentSMS(id,el);
    if(action==='sms-template'||action==='sms-clone')return templateModal(id,action==='sms-clone');
    if(action==='sms-variable'){const form=el.closest('form');const area=sms.lastArea?.isConnected?sms.lastArea:form.querySelector('[name=content]');area.setRangeText('{'+id+'}',area.selectionStart,area.selectionEnd,'end');area.focus();return;}
    if(action==='sms-credit'){el.disabled=true;try{const r=await api('sms/credit',{});document.getElementById('nasr-sms-credit').textContent=`اعتبار قابل استفاده: ${num(r.credit)} واحد پیامک`;}finally{el.disabled=false;}return;}
    if(action==='sms-process'){el.disabled=true;try{const r=await api('sms/process',{});await render();toast(r.last_error || r.message,!!r.last_error);}finally{el.disabled=false;}return;}
    if(action==='sms-test'){const key=uuid();return modal('ارسال یک پیامک آزمایشی',field('شمارهٔ دریافت تست','phone','',{dir:'ltr',mode:'tel',required:true})+''+check('ارسال فوری یک پیامک با هزینهٔ پنل را تأیید می‌کنم.','confirm',false),async form=>{const r=await api('sms/test',{...formData(form),request_key:key});closeModal();toast(r.message,r.test_result && ['failed','unknown'].includes(r.test_result.status));location.hash='sms/campaign/'+r.id;},'ارسال فوری پیام آزمایشی');}
    if(['sms-queue','sms-pause','sms-resume','sms-cancel'].includes(action)){
      const act=action.slice(4);if(act==='queue'){const count=sms.selection==='selected'?sms.selected.size:sms.current.counts.reduce((n,x)=>n+ +x.count,0);if(!count)throw new Error('حداقل یک مخاطب انتخاب کنید.');return modal('تأیید ارسال پیامک',`<p>پیامک برای ${num(count)} مخاطب در زمان برنامه‌ریزی و ساعات مجاز ارسال وارد صف می‌شود.</p>${check('متن‌ها و مخاطبان را بررسی کرده‌ام و ارسال را تأیید می‌کنم.','confirm',false)}`,async form=>{const r=await api('sms/campaigns/'+id,{action:act,process_now:true,confirm:formData(form).confirm,selection:sms.selection,ids:[...sms.selected]});closeModal();toast(r.message);await render();},'تأیید و ثبت در صف');}
      if(act==='cancel')return modal('لغو پیام‌های باقی‌مانده','<p>پیام‌هایی که هنوز ارسال نشده‌اند لغو می‌شوند. پیام در حال ارسال ممکن است تکمیل شود.</p>',async()=>{const r=await api('sms/campaigns/'+id,{action:act});closeModal();toast(r.message);await render();},'لغو باقی‌مانده‌ها');
      const r=await api('sms/campaigns/'+id,{action:act,process_now:act==='resume'});toast(r.message);return render();
    }
    if(action==='sms-delivery'){el.disabled=true;try{const r=await api('sms/messages/'+id,{action:'delivery'});await render();toast(r.message);}finally{el.disabled=false;}return;}
    if(action==='sms-retry'){const m=sms.current.items.find(m=>+m.id===+id);return modal('تلاش مجدد برای پیام',`<p>${h(m.recipient_name)} · <bdi>${h(m.recipient)}</bdi></p><pre class="nasr-sms-text">${h(m.content)}</pre>${m.status==='unknown'?check('پنل ملی‌پیامک را بررسی کرده‌ام و این پیام ارسال نشده است.','checked_provider',false):''}${check('ارسال مجدد همین پیام را تأیید می‌کنم.','confirm',false)}`,async form=>{const r=await api('sms/messages/'+id,{action:'retry',...formData(form)});closeModal();toast(r.message);await render();},'ثبت دوباره در صف');}
    if(action==='sms-optout-remove')return modal('حذف از فهرست عدم ارسال',`<p>شمارهٔ <bdi>${h(id)}</bdi> دوباره امکان دریافت پیامک‌های سامانه را خواهد داشت.</p>`,async()=>{await api('sms/optouts',{phone:id,remove:true});closeModal();await render();},'حذف از فهرست');
    if(action==='sms-export'){el.disabled=true;try{let page=1,res,rows=[];do{res=await api('sms/campaigns/'+id,undefined,{page:page++});rows.push(...res.items);}while(page<=res.pages);const cell=v=>'"'+String(v??'').replace(/^[\s]*([=+@-])/u,"'$1").replace(/"/g,'""')+'"';const data=[['نام','شماره','متن','وضعیت','تحویل','شناسه پیگیری','خطا','زمان'],...rows.map(m=>[m.recipient_name,m.recipient,m.content,smsStatus[m.status],m.delivery_text,m.rec_id,m.error_message,m.sent_at])];const url=URL.createObjectURL(new Blob(['\ufeff'+data.map(r=>r.map(cell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='nasr-sms-'+id+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}finally{el.disabled=false;}return;}
  }
  root.addEventListener('focusin',e=>{if(e.target.matches('textarea[name=content],textarea[name=params]'))sms.lastArea=e.target;});
  root.addEventListener('change',async e=>{try{const el=e.target;
    if(el.name==='mode'&&el.closest('#nasr-modal-form'))el.closest('form').querySelector('[data-sms-pattern]').hidden=el.value!=='pattern';
    if(el.name==='template_id'&&el.closest('#nasr-sms-preview'))templatePreview(el.closest('form'));
    if(el.name==='sms_selection')sms.selection=el.value;
    if(el.name==='sms_status'){sms.status=el.value;S.page=1;await render();}
    if(el.matches('[data-sms-recipient]')){if(el.checked)sms.selected.add(+el.dataset.smsRecipient);else sms.selected.delete(+el.dataset.smsRecipient);sms.selection='selected';root.querySelector('[name=sms_selection]').value='selected';root.querySelector('#nasr-sms-selected').textContent='انتخاب دستی: '+num(sms.selected.size)+' نفر';}
  }catch(e){toast(e.message,true);}});
  root.addEventListener('submit',async e=>{const form=e.target;if(!['nasr-sms-config','nasr-sms-preview','nasr-sms-optout'].includes(form.id))return;e.preventDefault();if(form.dataset.saving)return;form.dataset.saving='1';const submit=form.querySelector('[type=submit]');submit.disabled=true;
    try{const data=formData(form);if(form.id==='nasr-sms-config'){const r=await api('sms/config',data);await render();toast(r.message);}
      else if(form.id==='nasr-sms-optout'){const r=await api('sms/optouts',data);await render();toast(r.message);}
      else{if(!data.title)delete data.title;const r=await api('sms/preview',{...data,request_key:form.dataset.requestKey});toast(r.skipped?`${r.message} ${num(r.skipped)} مورد کنار گذاشته شد. ${(r.reasons || []).join(' ')}`:r.message);location.hash='sms/campaign/'+r.id;}
    }catch(error){toast(error.message,true);}finally{delete form.dataset.saving;submit.disabled=false;}
  });
  return {preferences,readPreferences,applyAppearance,printDocument,printTable,printRoster,printIndividual,smsPage,smsAction};
};

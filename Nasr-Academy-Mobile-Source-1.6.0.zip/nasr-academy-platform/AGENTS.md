# Nasr shared release source

- Keep the existing WordPress schema/data and mobile identity. Never uninstall the mobile package, clear app data, replace a user's keystore, change vault names, crypto aliases, localhost origin, app ID, or sign out users as part of an update.
- PHP/API and shared portal assets live in nasr-academy/. The PWA module is integrated in includes/class-webapp.php. The old standalone add-on is retired without deleting data.
- Canonical mobile CSS/UI/native authentication scripts live in nasr-academy/assets/mobile/. Do not edit mobile-app/public/ copies; prepare-core generates them from the canonical files. Browser and native authentication intentionally have separate adapters.
- Increase release.json version for a changed release. Run the shared release command to build the WordPress/PWA package, signed Android interface bundle and source archive together. Do not hand-edit built ZIPs.
- Reuse the existing private OTA signing key and public trust. Never generate a replacement key during normal releases or include private keys/keystores in WordPress ZIPs, APKs or source archives.
- Native changes require an APK signed with the original installation's signing key. Interface updates must retain native compatibility checks, signature verification, digest checks, safe ZIP paths, atomic staging and startup rollback.
- Keep all academic writes online. Do not add offline queues or browser storage for credentials/academic data.
- Verify modified PHP syntax, integrated PWA login/roles and code-update state transitions as appropriate. Preserve the working mobile design, remember-login and biometric behavior.
